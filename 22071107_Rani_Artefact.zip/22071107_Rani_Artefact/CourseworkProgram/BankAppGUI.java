import javax.swing.*; // Importing classes to create GUI components like buttons, labels, etc.
import java.awt.*; // Importing classes to manage layout, fonts, and graphical features.
import java.awt.event.ActionEvent; // Importing to handle action events, such as button clicks.
import java.awt.event.ActionListener; // Importing to listen for user actions, like pressing buttons.
import java.util.Date; // Importing to work with dates, useful for timestamping actions.

//****** I HAVE CREATED BOTH  GUI AND CONSOLE BASED METHOD, GUI IS LIMITED TO THE REQUIREMENTS BUT IF YOU WANT TO SEE THE ADDITIONAL FEATURES
// PLEASE GO TO MainConsoleApp.java :)

public class BankAppGUI { // Start of the BankAppGUI class which creates the graphical interface for the bank app.
    private BankService bankService; // Declare a variable to handle bank services, like account management.

    public BankAppGUI() { // Constructor of the class. This is where the GUI setup starts.
        bankService = new BankService(); // Initialize the bank service that will manage accounts and transactions.

        // Create the main window (JFrame) with a title and size.
        JFrame frame = new JFrame("Banking System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close the app when the window is closed.
        frame.setSize(600, 400); // Set the size of the window to 600x400 pixels.
        frame.setLayout(new GridLayout(6, 1)); // Arrange buttons in a grid with 6 rows and 1 column.

        // Create buttons for different actions like creating an account, displaying accounts, etc.
        JButton createAccountButton = new JButton("Create Account");
        JButton displayAccountsButton = new JButton("Display Accounts");
        JButton deleteAccountButton = new JButton("Delete Account");
        JButton updateTransactionButton = new JButton("Update Transaction");
        JButton displayTransactionsButton = new JButton("Display Last Four Transactions");
        JButton exitButton = new JButton("Exit");

        // Add listeners to handle button clicks. Each button triggers a different action.
        createAccountButton.addActionListener(e -> showCreateAccountDialog()); // When clicked, show account creation dialog.
        displayAccountsButton.addActionListener(e -> displayAccounts()); // When clicked, display all accounts.
        deleteAccountButton.addActionListener(e -> showDeleteAccountDialog()); // When clicked, show delete account dialog.
        updateTransactionButton.addActionListener(e -> showUpdateTransactionDialog()); // When clicked, show transaction update dialog.
        displayTransactionsButton.addActionListener(e -> showLastFourTransactionsDialog()); // When clicked, show last four transactions.
        exitButton.addActionListener(e -> System.exit(0)); // When clicked, close the application.

        // Add all the buttons to the frame (the main window).
        frame.add(createAccountButton);
        frame.add(displayAccountsButton);
        frame.add(deleteAccountButton);
        frame.add(updateTransactionButton);
        frame.add(displayTransactionsButton);
        frame.add(exitButton);

        // Make the frame visible to the user.
        frame.setVisible(true);
    }

    // Method to handle account creation when the "Create Account" button is clicked.
    private void showCreateAccountDialog() {
        // Create a new dialog window for account creation.
        JDialog dialog = new JDialog();
        dialog.setTitle("Create Account");
        dialog.setSize(400, 300); // Set the size of the dialog to 400x300 pixels.
        dialog.setLayout(new GridLayout(5, 2)); // Arrange the dialog elements in a grid.

        // Add input fields for account number, name, and address.
        JLabel accountNumberLabel = new JLabel("Account Number (7 digits):");
        JTextField accountNumberField = new JTextField();
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel addressLabel = new JLabel("Address:");
        JTextField addressField = new JTextField();
        JButton createButton = new JButton("Create");
        JButton cancelButton = new JButton("Cancel");

        // Add the components to the dialog.
        dialog.add(accountNumberLabel);
        dialog.add(accountNumberField);
        dialog.add(nameLabel);
        dialog.add(nameField);
        dialog.add(addressLabel);
        dialog.add(addressField);
        dialog.add(createButton);
        dialog.add(cancelButton);

        // Action for the "Create" button.
        createButton.addActionListener(e -> {
            try {
                int accountNumber = Integer.parseInt(accountNumberField.getText()); // Convert the entered account number to an integer.
                String name = nameField.getText(); // Get the name entered.
                String address = addressField.getText(); // Get the address entered.

                // Validate the account number length.
                if (String.valueOf(accountNumber).length() != 7) {
                    JOptionPane.showMessageDialog(dialog, "Account number must be 7 digits.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // If the input is valid, create the account through the bank service.
                    bankService.createAccount(accountNumber, name, address, new Date());
                    JOptionPane.showMessageDialog(dialog, "Account created successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose(); // Close the dialog after successful account creation.
                }
            } catch (NumberFormatException ex) {
                // Show an error if the account number is not valid (not an integer).
                JOptionPane.showMessageDialog(dialog, "Invalid input for account number.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Action for the "Cancel" button to close the dialog without creating an account.
        cancelButton.addActionListener(e -> dialog.dispose());

        // Show the account creation dialog.
        dialog.setVisible(true);
    }

    // Method to display a list of all accounts when the "Display Accounts" button is clicked.
    private void displayAccounts() {
        StringBuilder accountsInfo = new StringBuilder();
        // Loop through all bank accounts and add them to the string.
        for (BankAccount account : bankService.accounts.values()) {
            accountsInfo.append("Account Number: ").append(account.getAccountNumber())
                    .append(", Name: ").append(account.getAccountHolderName())
                    .append(", Address: ").append(account.getAccountHolderAddress())
                    .append(", Balance: ").append(account.getBalance()).append("\n");
        }

        // If no accounts are found, show a message.
        if (accountsInfo.length() == 0) {
            accountsInfo.append("No accounts found.");
        }

        // Show the accounts information in a message dialog.
        JOptionPane.showMessageDialog(null, accountsInfo.toString(), "Accounts", JOptionPane.INFORMATION_MESSAGE);
    }

    // Method to handle account deletion when the "Delete Account" button is clicked.
    private void showDeleteAccountDialog() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter account number to delete:"); // Prompt the user for the account number.
        try {
            int accountNumber = Integer.parseInt(accountNumberStr); // Convert the input to an integer.
            bankService.deleteAccount(accountNumber); // Attempt to delete the account via bank service.
            JOptionPane.showMessageDialog(null, "Account deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            // Show an error message if the account number is not valid.
            JOptionPane.showMessageDialog(null, "Invalid account number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Method to handle deposit or withdrawal transactions when the "Update Transaction" button is clicked.
    private void showUpdateTransactionDialog() {
        JDialog dialog = new JDialog();
        dialog.setTitle("Update Transaction");
        dialog.setSize(400, 200); // Set the size of the dialog to 400x200 pixels.
        dialog.setLayout(new GridLayout(4, 2)); // Arrange the components in a grid.

        // Add input fields for account number, transaction type, and amount.
        JLabel accountNumberLabel = new JLabel("Account Number:");
        JTextField accountNumberField = new JTextField();
        JLabel transactionTypeLabel = new JLabel("Transaction Type (deposit/withdraw):");
        JTextField transactionTypeField = new JTextField();
        JLabel amountLabel = new JLabel("Amount:");
        JTextField amountField = new JTextField();
        JButton updateButton = new JButton("Update");

        // Add the components to the dialog.
        dialog.add(accountNumberLabel);
        dialog.add(accountNumberField);
        dialog.add(transactionTypeLabel);
        dialog.add(transactionTypeField);
        dialog.add(amountLabel);
        dialog.add(amountField);
        dialog.add(updateButton);

        // Action for the "Update" button.
        updateButton.addActionListener(e -> {
            try {
                int accountNumber = Integer.parseInt(accountNumberField.getText()); // Get the account number.
                String transactionType = transactionTypeField.getText(); // Get the transaction type (deposit or withdraw).
                double amount = Double.parseDouble(amountField.getText()); // Get the amount for the transaction.

                // Update the transaction via the bank service and show the updated balance.
                double updatedBalance = bankService.updateTransaction(accountNumber, amount, transactionType);
                if (updatedBalance != -1) {
                    JOptionPane.showMessageDialog(dialog, "Transaction successful. Updated balance: $" + updatedBalance);
                    dialog.dispose(); // Close the dialog after a successful transaction.
                } else {
                    JOptionPane.showMessageDialog(dialog, "Transaction failed.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                // Show an error if the input is invalid (not a number).
                JOptionPane.showMessageDialog(dialog, "Invalid input.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Show the dialog.
        dialog.setVisible(true);
    }

    // Method to show the last four transactions when the "Display Last Four Transactions" button is clicked.
    private void showLastFourTransactionsDialog() {
        String accountNumberStr = JOptionPane.showInputDialog("Enter account number:"); // Ask for the account number.
        try {
            int accountNumber = Integer.parseInt(accountNumberStr); // Convert the input to an integer.
            BankAccount account = bankService.accounts.get(accountNumber); // Get the account by number.
            if (account != null) {
                // Show the last four transactions of the account.
                StringBuilder transactionsInfo = new StringBuilder("Last 4 Transactions:\n");
                for (Transaction transaction : account.getTransactionQueue().getSortedTransactions()) {
                    transactionsInfo.append(transaction).append("\n");
                }
                JOptionPane.showMessageDialog(null, transactionsInfo.toString(), "Transactions", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Account not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            // Show an error if the account number is invalid.
            JOptionPane.showMessageDialog(null, "Invalid account number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) { 
        new BankAppGUI(); // Create an instance of the BankAppGUI, which initializes and shows the interface.
    }
}
