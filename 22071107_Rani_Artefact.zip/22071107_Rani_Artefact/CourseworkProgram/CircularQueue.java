import java.util.ArrayList;

public class CircularQueue {
    // The queue will hold an array of Transaction objects.
    private Transaction[] queue;
    // 'front' will point to the index of the oldest transaction in the queue.
    private int front;
    // 'rear' will point to the index of the most recent transaction added.
    private int rear;
    // 'size' will track the current number of elements in the queue.
    private int size;
    // 'capacity' will hold the maximum number of transactions the queue can store.
    private int capacity;

    // Constructor to initialize the CircularQueue with a specified capacity.
    // The queue will store up to 'capacity' number of transactions.
    public CircularQueue(int capacity) {
        this.capacity = capacity;
        this.queue = new Transaction[capacity]; // Create an array to store transactions.
        this.front = 0;  // Front of the queue starts at index 0.
        this.rear = -1;  // Rear starts at -1 because no element has been added yet.
        this.size = 0;   // Initially, the queue is empty.
    }

    // Method to add a transaction to the queue (enqueue).
    public void enqueue(Transaction transaction) {
        // If the queue is full (i.e., size equals capacity), we overwrite the oldest transaction.
        if (size == capacity) {
            front = (front + 1) % capacity; // Increment 'front' to overwrite the oldest transaction.
        } else {
            size++;  // Increase the size of the queue.
        }
        // Move 'rear' to the next index in a circular manner (modulo capacity ensures wraparound).
        rear = (rear + 1) % capacity;
        // Insert the new transaction into the queue at the 'rear' position.
        queue[rear] = transaction;
    }

    // Method to retrieve all transactions from the queue as an ArrayList.
    public ArrayList<Transaction> getTransactions() {
        ArrayList<Transaction> transactions = new ArrayList<>();
        // Loop over the current size of the queue to collect the transactions in the correct order.
        for (int i = 0; i < size; i++) {
            // Use the modulo operator to handle the circular nature of the queue.
            transactions.add(queue[(front + i) % capacity]);
        }
        return transactions;  // Return the list of transactions.
    }

    public ArrayList<Transaction> getSortedTransactions() {
        ArrayList<Transaction> transactions = getTransactions(); // Get transactions in natural order
        transactions.sort((t1, t2) -> Double.compare(t1.getAmount(), t2.getAmount())); // Sort by amount
        return transactions;
    }

    public void enqueue(String string) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'enqueue'");
    }
        
    }

