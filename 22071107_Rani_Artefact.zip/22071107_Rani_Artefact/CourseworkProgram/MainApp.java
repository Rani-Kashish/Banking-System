import java.util.Date; 
import java.util.InputMismatchException;
import java.util.Scanner;
//*********************************this console is specified on the requirements of the csw, additional featurers are in the MainConsoleApp.JAVA
public class MainApp {
    // Define constants for ANSI escape codes to add color to text output (used to style the console)
    public static final String RESET = "\u001B[0m";  // Reset color to default
    public static final String RED = "\u001B[31m";  // Red color for error messages
    public static final String ORANGE = "\u001B[38;5;208m";  // Orange color for general information
    public static final String YELLOW = "\u001B[33m";  // Yellow color for highlighting
    public static final String GREEN = "\u001B[32m";  // Green color for success messages
    public static final String BLUE = "\u001B[34m";  // Blue color for general prompts
    public static final String INDIGO = "\u001B[38;5;54m";  // Indigo color for input prompts
    public static final String VIOLET = "\u001B[35m";  // Violet color for transaction-related prompts

    public static void main(String[] args) {
        // Create an instance of the BankService class to handle bank-related operations like creating accounts
        BankService bankService = new BankService();
        
        // Create a Scanner object to read user input from the console
        Scanner scanner = new Scanner(System.in);
        
        // Declare a variable 'choice' to store the user's menu selection
        int choice;  

        do {
            // Display the menu options to the user, each colored using the constants defined above
            System.out.println(RED + "1. Create Account" + RESET);  // Red color for "Create Account" option
            System.out.println(ORANGE + "2. Display Accounts" + RESET);  // Orange color for "Display Accounts" option
            System.out.println(YELLOW + "3. Delete Account" + RESET);  // Yellow color for "Delete Account" option
            System.out.println(GREEN + "4. Update Transaction" + RESET);  // Green color for "Update Transaction" option
            System.out.println(BLUE + "5. Display Last Four Transactions" + RESET);  // Blue color for "Display Last Four Transactions" option
            System.out.println(VIOLET + "6. Exit" + RESET);  // Violet color for "Exit" option

            // Ask the user to enter their choice from the menu
            System.out.print(INDIGO + "Enter your choice: " + RESET);  // Use indigo color for the prompt

            try {
                // Read the user's choice (a number) and store it in 'choice'
                choice = scanner.nextInt();
                
                // Process the user's choice using a switch statement
                switch (choice) {
                    // Case 1: Create a new account
                    case 1:
                        int accountNumber = 0;  // Initialize variable to store the account number
                        boolean validAccountNumber = false;  // Flag to track if the account number is valid

                        // Loop until a valid 7-digit account number is entered
                        while (!validAccountNumber) {
                            System.out.print(RED + "Enter Account Number (7 digits): " + RESET);  // Prompt user for account number
                            try {
                                accountNumber = scanner.nextInt();  // Read the account number
                                
                                // Check if the account number has exactly 7 digits
                                if (String.valueOf(accountNumber).length() == 7) {
                                    validAccountNumber = true;  // Mark the account number as valid if it has 7 digits
                                } else {
                                    System.out.println(RED + "Error: Account number must be exactly 7 digits." + RESET);  // Error message if invalid
                                }
                            } catch (InputMismatchException e) {
                                // Catch error if user enters a non-integer value for the account number
                                System.out.println(RED + "Error: Please enter a valid integer for the account number." + RESET);
                                scanner.next();  // Consume the invalid input to prevent an infinite loop
                            }
                        }

                        // Consume the newline left behind by nextInt
                        scanner.nextLine(); 

                        String name = "";  // Initialize variable to store the holder's name
                        boolean validName = false;  // Flag to track if the name is valid

                        // Loop until a valid name is entered (only letters and spaces)
                        while (!validName) {
                            System.out.print(ORANGE + "Enter Holder Name: " + RESET);  // Prompt user for name
                            name = scanner.nextLine();  // Read the name input
                            
                            // Check if the name contains only letters and spaces
                            if (name.matches("[a-zA-Z ]+")) {
                                validName = true;  // Name is valid
                            } else {
                                System.out.println(ORANGE + "Error: Name must contain only letters and spaces." + RESET);  // Error message if invalid
                            }
                        }

                        String address = "";  // Initialize variable to store the holder's address
                        boolean validAddress = false;  // Flag to track if the address is valid

                        // Loop until a valid address is entered (only letters, numbers, and basic special characters)
                        while (!validAddress) {
                            System.out.print(YELLOW + "Enter Holder Address: " + RESET);  // Prompt user for address
                            address = scanner.nextLine();  // Read the address input
                            
                            // Check if the address contains valid characters
                            if (address.matches("[a-zA-Z0-9 ,.-]+")) {
                                validAddress = true;  // Address is valid
                            } else {
                                System.out.println(YELLOW + "Error: Address must contain only valid characters." + RESET);  // Error message if invalid
                            }
                        }

                        // Call the createAccount method from BankService to create the account with the provided details
                        bankService.createAccount(accountNumber, name, address, new Date());
                        break;  // Break out of the switch case after creating the account

                    // Case 2: Display all accounts
                    case 2:
                        System.out.println(GREEN + "Displaying all accounts..." + RESET);  // Inform the user that accounts will be displayed
                        bankService.displayAccounts();  // Call method to display all accounts
                        break;  // Break out of the switch case

                    // Case 3: Delete an account
                    case 3:
                        System.out.print(BLUE + "Enter Account Number to delete: " + RESET);  // Prompt user for the account number to delete
                        int deleteAccountNumber = 0;  // Initialize variable to store the account number to delete
                        
                        try {
                            deleteAccountNumber = scanner.nextInt();  // Read the account number input
                        } catch (InputMismatchException e) {
                            // Catch error if user enters a non-integer value for the account number
                            System.out.println(RED + "Error: Please enter a valid integer for the account number." + RESET);
                            scanner.next();  // Consume the invalid input to prevent an infinite loop
                        }
                        // Call method to delete the account with the given number
                        bankService.deleteAccount(deleteAccountNumber);
                        break;  // Break out of the switch case

                    // Case 4: Update a transaction (deposit or withdrawal)
                    case 4:
                        System.out.print(VIOLET + "Enter account number: " + RESET);  // Prompt user for the account number
                        int updateAccountNumber = scanner.nextInt();  // Read the account number
                        
                        System.out.print(INDIGO + "Enter transaction type (deposit/withdraw): " + RESET);  // Prompt for transaction type
                        String transactionType = scanner.next();  // Read the transaction type (deposit/withdraw)
                        
                        System.out.print(RED + "Enter transaction amount: " + RESET);  // Prompt for transaction amount
                        double amount = scanner.nextDouble();  // Read the transaction amount
                        
                        // Call method to update the transaction and get the updated balance
                        double updatedBalance = bankService.updateTransaction(updateAccountNumber, amount, transactionType);
                        
                        // Check if the transaction was successful and display the result
                        if (updatedBalance != -1) {
                            System.out.printf(GREEN + "Transaction successful. Updated balance: $%.2f\n" + RESET, updatedBalance);  // Success message
                        } else {
                            System.out.println(RED + "Transaction failed. Please try again." + RESET);  // Failure message
                        }
                        break;  // Break out of the switch case

                    // Case 5: Display the last four transactions of an account
                    case 5:
                        System.out.print(YELLOW + "Enter Account Number: " + RESET);  // Prompt user for the account number
                        int transactionAccountNumber = scanner.nextInt();  // Read the account number
                        
                        // Call method to display the last four transactions for the given account
                        bankService.displayLastFourTransactions(transactionAccountNumber);
                        break;  // Break out of the switch case

                    // Case 6: Exit the application
                    case 6:
                        System.out.println(ORANGE + "Exiting..." + RESET);  // Inform the user that the application will exit
                        break;  // Break out of the switch case

                    // Default case: Handle invalid menu choices
                    default:
                        System.out.println(RED + "Invalid choice. Please try again." + RESET);  // Show error message for invalid input
                }
            } catch (InputMismatchException e) {
                // Catch error if the input is not a valid number
                System.out.println(RED + "Invalid input. Please enter a number." + RESET);
                scanner.next();  // Consume the invalid input to prevent an infinite loop
                choice = -1;  // Set choice to an invalid number to continue the loop
            }
        } while (choice != 6);  // Loop until the user chooses to exit (option 6)

        // Close the scanner to release the resources
        scanner.close();
    }
}  