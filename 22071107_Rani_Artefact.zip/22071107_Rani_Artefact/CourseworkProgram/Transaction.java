import java.util.Date;
//this is my transaction class attributes
public class Transaction {
    private String type; // deposit or withdrawal
    private double amount; //amout to update the transaction
    private Date date; //current date and time by using pacakge 
    // initilise the parameters
    public Transaction(String type, double amount, Date date) {
        this.type = type;
        this.amount = amount;
        //this.date = date;
        this.date = (date != null) ? date : new Date(); // Default to current date if no date provided
    }

    // Overloaded constructor for convenience (uses current date)
    public Transaction(String type, double amount) {
        this(type, amount, new Date());
    }


    // from here its going to be methods for this class (getter methods)
    public String getType() {

        return type; //it will return either the withdraw or deposit
    }

    public double getAmount() {
        return amount; //it will return the amount
    }

    public Date getDate() {
        return date; //it will return the date
    }
    //using encapsulation to avoid the errors 
    @Override
    public String toString() { //using overrinding to make suree there are less chances for errors
        return "Transaction{" +
            "type='" + type + '\'' +
            ", amount=" + amount +
            ", date=" + date +
            '}';
    }
}