import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.io.*;

// BankService class handles all operations related to bank accounts, such as creating accounts, 
// updating balances, saving/loading account data, searching for accounts, and displaying transactions.
public class BankService {
    // Declaring a HashMap to store accounts. The key is the account number (Integer) and 
    // the value is a BankAccount object that contains the account details.
    HashMap < Integer, BankAccount > accounts;

    // Constructor to initialize the accounts HashMap. This is invoked when a new BankService object is created.
    public BankService() {
        // Initializing the accounts HashMap. This is used to store all the accounts in the system.
        accounts = new HashMap < > (); // A HashMap stores unique keys (account numbers) and corresponding values (BankAccount objects).
    }

    // Method to create a new bank account. It takes accountNumber, name, address, and openingDate as parameters.
    public void createAccount(int accountNumber, String name, String address, Date openingDate) {
        // Check if the account number already exists in the HashMap.
        // If it doesn't exist, we proceed to create the account.
        if (!accounts.containsKey(accountNumber)) {
            // Creating a new BankAccount object with the given parameters.
            BankAccount account = new BankAccount(accountNumber, name, address, openingDate);
            // Adding the newly created account to the accounts HashMap.
            // The account number is used as the key, and the BankAccount object is the value.
            accounts.put(accountNumber, account);
            // Notify the user that the account was created successfully.
            System.out.println("Account created successfully.");
        } else {
            // If the account number already exists, we inform the user that the account cannot be created.
            System.out.println("Account number already exists.");
        }
    }

    // Method to display all the accounts in the system.
    // It loops through all the values in the accounts HashMap and prints out account details.
    public void displayAccounts() {
        // Looping through all the accounts stored in the HashMap.
        // accounts.values() returns a collection of all the BankAccount objects in the map.
        for (BankAccount account: accounts.values()) {
            // Printing the account details, including account number, holder's name, address, and balance.
            System.out.println(account);
        }
    }

    // Method to delete an account by its account number.
    public void deleteAccount(int accountNumber) {
        // Attempt to remove the account from the HashMap using the account number as the key.
        // If the account is removed, the method returns the removed BankAccount object; otherwise, it returns null.
        if (accounts.remove(accountNumber) != null) {
            // If the account was successfully removed, we inform the user.
            System.out.println("Account deleted successfully.");
        } else {
            // If no account with that number exists, inform the user that the account was not found.
            System.out.println("Account not found.");
        }
    }

    // Method to update the account balance by either depositing or withdrawing money.
    // It takes accountNumber, amount, and transactionType as parameters.
    public double updateTransaction(int accountNumber, double amount, String transactionType) {
        // First, check if the account exists in the HashMap by checking if the account number is present as a key.
        if (!accounts.containsKey(accountNumber)) {
            // If the account doesn't exist, print an error message and return -1 to indicate failure.
            System.out.println("Account number " + accountNumber + " does not exist.");
            return -1;
        }

        // Retrieve the BankAccount object associated with the provided account number.
        BankAccount account = accounts.get(accountNumber);

        // If the transaction type is deposit, we attempt to deposit the specified amount into the account.
        if (transactionType.equalsIgnoreCase("deposit")) {
            // Call the deposit method on the BankAccount object. If the deposit is successful, print a success message.
            if (account.deposit(amount)) {
                System.out.println("Deposit successful.");
            } else {
                // If the deposit fails, return -1 to indicate failure.
                return -1;
            }
        }
        // If the transaction type is withdraw, we attempt to withdraw the specified amount from the account.
        else if (transactionType.equalsIgnoreCase("withdraw")) {
            // Call the withdraw method on the BankAccount object. If the withdrawal is successful, print a success message.
            if (account.withdraw(amount)) {
                System.out.println("Withdraw successful.");
            } else {
                // If the withdrawal fails (e.g., insufficient funds), return -1 to indicate failure.
                return -1;
            }
        }
        // If the transaction type is neither "deposit" nor "withdraw", print an error message.
        else {
            // Inform the user that the transaction type is invalid.
            System.out.println("Invalid transaction type. Please enter 'deposit' or 'withdraw'.");
            return -1; // Return -1 to indicate failure due to invalid transaction type.
        }

        // After the transaction, return the updated account balance.
        return account.getBalance();
    }


//******************************************additional features******************************************************************************************//
    public void searchByAccountHolderName(String name) { //user can find the account by using their name
        boolean found = false;

        // Iterate over all accounts in the 'accounts' HashMap
        for (BankAccount account: accounts.values()) {
            if (account.getAccountHolderName().equalsIgnoreCase(name)) {
                // Print the details of the account if the name matches
                System.out.println(account); // This will call the toString method of the BankAccount class
                found = true;
            }
        }

        // If no account was found for the given name
        if (!found) {
            System.out.println("No account found for the name: " + name);
        }
    }
//******************************************additional features******************************************************************************************//
    // Method to update account details (name and address)
    public void updateAccountDetails(int accountNumber, String newName, String newAddress) {
        // Check if the account exists in the HashMap
        if (accounts.containsKey(accountNumber)) {
            BankAccount account = accounts.get(accountNumber); // Retrieve the account

            try {
                // Update the account holder's name
                if (newName != null && !newName.trim().isEmpty()) {
                    account.setHolderName(newName);
                }

                // Update the account holder's address
                if (newAddress != null && !newAddress.trim().isEmpty()) {
                    account.setAddress(newAddress);
                }

                System.out.println("Account details updated successfully.");
                System.out.println(account); // Display updated account details
            } catch (Exception e) {
                System.out.println("Error updating account details: " + e.getMessage());
            }
        } else {
            System.out.println("Account not found for number: " + accountNumber);
        }
    }
 //******************************************additional features******************************************************************************************//



    // Method to search for an account by the account holder's address.
    public void searchByAccountHolderAddress(String address) {
        boolean found = false; // Flag to check if any account is found.

        // Loop through all accounts in the HashMap.
        for (BankAccount account: accounts.values()) {
            // If the account holder's address matches the search address (case-insensitive), print the account details.
            if (account.getAccountHolderAddress().equalsIgnoreCase(address)) {
                System.out.println(account); // Print account details.
                found = true; // Mark that an account was found.
            }
        }

        // If no account with the specified address is found, inform the user.
        if (!found) {
            System.out.println("No account found with the address: " + address);
        }
    }
//******************************************i havent explain additional code in the video, instead i put comment and i explained in the repo******************************************************************************************//

    // Method to display the last four transactions of a given account number.
    public void displayLastFourTransactions(int accountNumber) {
        // Try to retrieve the account using the given account number.
        BankAccount account = accounts.get(accountNumber);

        // If the account exists, proceed to display the last four transactions.
        if (account != null) {
            // Retrieve the list of transactions from the account.
            ArrayList < Transaction > transactions = account.getTransactionQueue().getTransactions();

            // Check if there are any transactions in the list.
            if (transactions.size() > 0) {
                System.out.println("Displaying last 4 transactions for Account Number: " + accountNumber);
                // Sort the transactions in ascending order based on the amount using insertion sort.
                insertionSort(transactions);

                // Display the last four transactions (or all if fewer than four).
                int count = Math.min(transactions.size(), 4);
                for (int i = 0; i < count; i++) {
                    System.out.println(transactions.get(i)); // Print each transaction's details.
                }
            } else {
                // If no transactions exist, inform the user.
                System.out.println("No transactions found for this account.");
            }
        } else {
            // If no account with the given number exists, inform the user.
            System.out.println("Account not found.");
        }
    }

    // Method to sort transactions by amount in ascending order using insertion sort.
    private void insertionSort(ArrayList < Transaction > transactions) {
        // Insertion sort algorithm: Iterates through the list of transactions and places each transaction 
        // in its correct position relative to others by shifting larger elements to the right.
        for (int i = 1; i < transactions.size(); i++) {
            Transaction key = transactions.get(i); // Pick the current transaction to compare.
            int j = i - 1;

            // Shift transactions that are larger than the current one to the right.
            while (j >= 0 && transactions.get(j).getAmount() > key.getAmount()) {
                transactions.set(j + 1, transactions.get(j)); // Move the transaction to the right.
                j = j - 1; // Move leftwards to continue shifting larger elements.
            }
            // Place the current transaction (key) in its correct position.
            transactions.set(j + 1, key);
        }
    }

    public void searchByName(String searchName) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'searchByName'");
    }
}