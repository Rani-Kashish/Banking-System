import java.util.Date;
//this is my Bank Account class where i stored the user details and use the data algorithm from teh scratch
//// instance variables
public class BankAccount {
    private int accountNumber; //A unique number for each bank account, like a name tag.
    private String accountHolderName; //The name of the person who owns the account
    private String accountHolderAddress; //The home address of the account owner
    private Date openingDate; //The date when the account was created
    private double balance; //The amount of money in the account.
    private CircularQueue transactionQueue; //A special list that remembers the last 4 things that happened with the money (like deposits and withdrawals).
    //I PREFER TO USE THE CIRCULAR QUEUE AS IT WILL HELP VIA BUFFER
    //The CircularQueue fulfills the specific requirement: "The system should maintain details of the last 4 transactions for each account."
    //It does not use any prebuilt Java collections like ArrayList, LinkedList, or Deque for its internal operations.
    //The implementation is entirely custom, including handling circular indexing and overwriting.
    /* **Automatic Overwriting**: No need for manual deletion of old items.
     **Efficiency**: Fixed-size storage uses minimal memory.
     **Order Preservation**: The queue maintains the correct order of elements, ensuring you can retrieve them easily.*/


    //Constructor for objects. This is like a recipe for making a new bank account. It sets up all the important information when you create a new account 
    public BankAccount(int accountNumber, String accountHolderName, String accountHolderAddress, Date openingDate) {
        this.accountNumber = accountNumber; // Initialize account number
        this.accountHolderName = accountHolderName; //Initialize account holder's name
        this.accountHolderAddress = accountHolderAddress; //Initialize account holder's address
        this.openingDate = openingDate; //Initialize opening date
        this.balance = 0.0; //Set initial balance to zero
        this.transactionQueue = new CircularQueue(4); // Store last 4 transactions
    }
    //Overloaded constructo
    public BankAccount(String name, String address, String accountNumber2, Date currentDate) {

    }

    //METHODS GETTERS
    public int getAccountNumber() {
        return accountNumber; // returns the account number
    }
    public void setHolderName(String holderName) {
        this.accountHolderName = holderName;
    }
    public String getAccountHolderName() {
        return accountHolderName; //returns the account holder name
    }
    public void setAddress(String address) {
        this.accountHolderAddress = address;
    }
    public String getAccountHolderAddress() {
        return accountHolderAddress; //return the address
    }

    public Date getOpeningDate() {
        return openingDate; //return the date
    }

    public double getBalance() {
        return balance; //retuRN the balance
    }


    //THIS FUNCTION PRESENT TYPE DEPOSIT THAT GONNA ADD UP WITH THE PREVIOUS BALANCE AND THE QUEUE GOONA NOTE IT 
    public boolean deposit(double amount) {
        if (amount <= 0) {
            System.out.println("YOU CAN NOT PUT INVALID AMMOUNT, HAS TO BE MORE THAN 0."); //balance cant be negative or 0
            return false;
        } else {
            balance += amount;
            transactionQueue.enqueue(new Transaction("Deposit", amount, new Date()));
            return true; // Return true for successful deposit
        }
    }
    //IN THIS WHEN THE USER IS ABOUT TO TAKE OUT THE MONEY BUT THERE ARE NO SUFFICIENT FUNDS HE/SHE WILL UNABLR AND AN ERROR WILL APPREAR AND AMOUNT WILL GOING TO MINUS FROM BALANCE
    public boolean withdraw(double amount) {
        if (balance <= amount) {
            System.out.println("Insufficient funds for withdrawal.");
            return false; // Insufficient funds
        } else if (amount <= 0) {
            System.out.println("YOU CAN NOT PUT INVALID AMMOUNT, HAS TO BE MORE THAN 0.");
            return false; //return false if its unsuccessfull
        } else {
            balance -= amount;
            transactionQueue.enqueue(new Transaction("Withdrawal", amount, new Date()));
            // Record transaction in queue

        }
        return true;

    }
    public void setBalance(double balance) {
        this.balance = balance; //// Setter method to update the balance (if needed)
    }

    public CircularQueue getTransactionQueue() { //// Getter method to access the transaction queue
        return transactionQueue; // Return the transaction queue
    }

    @Override
    public String toString() {
        return "Account Number: " + accountNumber + ", Holder Name: " + getAccountHolderName() +
            ", Address: " + accountHolderAddress + ", Balance: $" + balance;
    }

}